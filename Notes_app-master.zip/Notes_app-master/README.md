# ![alt text](https://github.com/Helium-He/Notes_app/blob/master/raws/github_icon_header.png "Logo Title Text 1") Notes_app
## Simple Notes taking android app using Firebase

# [Click to download](https://github.com/Helium-He/Notes_app/raw/master/raws/Notes_app.apk)

### Features
* Firebase
* simple
* beautiful gui
* Good for beginners
## ScreenShots
![alt text](https://github.com/Helium-He/Notes_app/blob/master/raws/screens.png "Logo Title Text 1")

### Login for guests
Email: guests@gmail.com
Password: iamguest

## Enjoy and learn :smile:
